# A-Gold-Crown
A Gold Crown Problem form geektrust
